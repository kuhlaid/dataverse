Test case 2023.12.11 - replacement file
--- 
Test to check that a zip file named 11.zip can be replaced in a dataset with another zip file with the same name but different contents, without having the file duplicated instead and automatically renamed to 11-1.zip.